import random

random.seed(None)
(a,b)=(random.randint(1, 1000000000),random.randint(1, 1000000000))
print min(a,b) ,max (a,b)
