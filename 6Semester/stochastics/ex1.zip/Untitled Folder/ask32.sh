for i in `seq 2 15`;
do
	echo $i |python ex32.py >> ask32.txt
done
